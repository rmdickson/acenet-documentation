function asa = getAdditionalSubmitArguments(props)

% http://www.ace-net.ca/wiki/Placentia
% https://www.ace-net.ca/wiki/MATLAB

% Copyright 2010-2014 The MathWorks, Inc.

% first set the parallel environment

[~,flag] = strtok(props.MatlabArguments,'p');
if strcmp(flag,'parallel')
    w = props.NumberOfTasks;
else
    w = 1;
end

asa = sprintf(' -pe matlab %d', w);

%% REQUIRED


%% OPTIONAL

% Walltime
wt = ClusterInfo.getWallTime();
if isempty(wt)==true
    % h_rt sets the hard time limit
    % Default: 48 hours
    % hh:mm:ss
    wt = '48:0:0';
end
asa = [asa ' -l h_rt=' wt];

% Memory usage per process
mu = ClusterInfo.getMemUsage();
if isempty(mu)==true
    % h_vmem sets the hard memory limit per parallel process
    % Default: 4G
    mu = '4G';
end
asa = [asa ' -l h_vmem=' mu];

% Check if user wants email updates
ea = ClusterInfo.getEmailAddress();
if isempty(ea)==false
    % User wants to be emailed the job status
    asa = [asa ' -M ' ea ' -m abes'];
end

% Every job is going to require a certain number of MDCS licenses.
% Specifing one MDCS per requested slot
asa = [asa ' -l dce=1'];

% Catch-all
udo = ClusterInfo.getUserDefinedOptions();
if isempty(udo)==false
    asa = [asa ' ' udo];
end

asa = strtrim(asa);
