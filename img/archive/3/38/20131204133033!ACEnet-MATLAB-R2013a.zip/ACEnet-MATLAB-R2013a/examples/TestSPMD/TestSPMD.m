function TestSPMD

% Example of using SPMD option.
%
% This code generates random 10000x10000 complex matrix, and then 
% performs its inversion in parallel on several number of workers using the
% spmd directive. For comparison, the same matrix is later inverted on 1
% worker only.
% 
% This example also shows how to include in your job externally defined 
% functions (or data files). 
%
% Use sgeParams.m file to set the requested walltime for the job.
% The sgeParams.m file must always be in your MATLAB path.
%
% Job submission commands:
%
%  >> myCluster = parcluster('Placentia')
%  >> j = batch(myCluster,'TestSPMD', 'matlabpool', 5,'AttachedFiles',{'data'})
%
%  5 is a sample matlabpool size. The total number of cores used will be
%  6. The 'AttachedFiles' option is used to send the content of "data"
%  folder to the cluster to be used in your job (can be matlab scripts or 
%  data files)

clear all;


N=10000;

filename='~/output_test_spmd.txt';
outfile = fopen(filename,'w');
fprintf(outfile, 'CALCULATION LOG: \n\n');


H=Ham(N);

H1=distributed(H);


%deye = distributed.eye(N); 

tic;
spmd
    %X = H\deye; % explicitly compute the inverse
    inv(H1);
end
t2=toc;

fprintf(outfile, 'Time parallel = %12f\n', t2);

%leye=eye(N);

tic;
%lx = Ham\leye;
inv(H);
t2=toc;

fprintf(outfile, 'Time serial = %12f\n', t2);


fprintf(outfile, 'CALCULATIONS DONE ...  \n\n');

fclose(outfile);


