function state = pGetJobState(scheduler, job, state)
%pGetJobState Gets the state of a job on a cluster.
% Place this file in the directory
% $MATLABROOT/toolbox/distcomp/@distcomp/@abstractscheduler/

%  Copyright 2006 The MathWorks, Inc.

mlock;
persistent jobsToMonitorNames;

if isempty(jobsToMonitorNames)
    jobsToMonitorNames = {};
end

jobName = job.Name;
if strcmp(state, 'finished')
    jobsToMonitorNames = setxor(jobsToMonitorNames, {jobName});
else
    if strcmp(state, 'queued') || strcmp(state, 'running')
        if ~ismember(jobName, jobsToMonitorNames)
            jobsToMonitorNames = union(jobsToMonitorNames, {jobName});
            jobStateTimer = timer('Period', 10.0, 'ExecutionMode', 'fixedRate');
            set(jobStateTimer, 'TimerFcn', { @copyJobFilesIfFinished, scheduler, job });
            start(jobStateTimer);
        end
    end
end
