function pDestroyJob(scheduler, job)
; %#ok Undocumented
%pDestroyJob destroys job files on a remote host.
% Place this file in the directory
% $MATLABROOT/toolbox/distcomp/@distcomp/@abstractscheduler/

%  Copyright 2006 The MathWorks, Inc.

userData = scheduler.UserData;
clusterHost = userData{1};
remoteDataLocation = userData{2};
jobLocation = job.Name;
remoteJobDirectory = [ remoteDataLocation '/' jobLocation ];
remoteJobFiles = [ remoteDataLocation '/' jobLocation '.*' ];

%Remote destroy commands to run
destroyRemoteJobDirectory = sprintf('rm -rf %s', remoteJobDirectory);
destroyRemoteJobFiles = sprintf('rm -rf %s', remoteJobFiles);

% Execute the destroy commands on the remote host.
runCmdOnCluster(destroyRemoteJobDirectory, clusterHost);
runCmdOnCluster(destroyRemoteJobFiles, clusterHost);
