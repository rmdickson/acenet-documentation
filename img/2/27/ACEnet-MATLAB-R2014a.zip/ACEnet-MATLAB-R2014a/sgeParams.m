function lParams = sgeParams()
%SGEPARAMS Supply a resource request string
% customized to ACEnet's Grid Engine policies.

% CHANGE THESE IF YOU NEED TO:

% h_rt sets the hard time limit, hh:mm:ss
lParams = '-l h_rt=1:0:0';

% h_vmem sets the hard memory limit per parallel process
lParams = strcat(lParams, ',h_vmem=3G');

% DO NOT CHANGE ANYTHING FROM HERE DOWN:

% dce ensures there are sufficient licenses available before
%     scheduling the job
lParams = strcat(lParams, ',dce=1');

% glibc ensures the job is run on a machine with an adequate
%     operating system version
lParams = strcat(lParams, ',os=RHEL6');

