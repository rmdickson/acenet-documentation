function configCluster
% Configure MATLAB for users running remotely to the cluster.
%   1. Imports partial profile
%   2. Determines and creates (if needed) local job storage location
%   3. Updates profile and sets it as the default

% Copyright 2013-2014 The MathWorks, Inc.

% The location of MATLAB as compared to the cluster
type = 'remote';

% The version of MATLAB being supported
release = ['R' version('-release')];

% ACEnet
site = 'acenet';

% The location of the cluster setting file(s)
pfile_loc = fileparts(mfilename('fullpath'));

% Listing of setting file(s).  Derive the specific one to use.
pfiles = fullfile(pfile_loc,'*.settings');
pfile_listing = dir(pfiles);
if isempty(pfile_listing)==true
    error('Failed to find profiles.  Contact your System Administrator.')
elseif length(pfile_listing)>1
    pfile = lExtractPfile(pfile_listing);
else
    pfile = pfile_listing.name;
end

% From the settings file, derive the name of the cluster
cluster = strtok(pfile,'_');

% Create user's Job Storage Location folder
rootd = tempdir;
jfolder = fullfile(rootd,'MdcsDataLocation',site,cluster,release,type);
if exist(jfolder,'dir')==false
    [status,err,eid] = mkdir(jfolder);
    if status==false
        error(eid,err)
    end
end

% From the settings file, derive the name of the Profile
[~,profile] = fileparts(pfile);

% Delete the old profile (if it exists)
profiles = parallel.clusterProfiles();
idx = strcmp(profiles,profile);
ps = parallel.Settings;
ws = warning;
warning off %#ok<WNOFF>
ps.Profiles(idx).delete
warning(ws)

% Import the new profile
p = parallel.importProfile(fullfile(pfile_loc,pfile));

% Remote Job Storage Location
uname = input(['ACEnet username on ' upper(cluster) ': '],'s');
if isempty(uname)
    error(['Failed to configure cluster: ' cluster])
end
% Site specific
rootd = ['/home/' uname];
rjsl = [rootd '/MdcsDataLocation/' site '/' cluster '/' release '/' type];

% Get a handle to the profile
c = parcluster(p);
c.JobStorageLocation = jfolder;
c.IndependentSubmitFcn{3} = rjsl;
c.CommunicatingSubmitFcn{3} = rjsl;
c.saveProfile

% Set as default profile
parallel.defaultClusterProfile(p);

% Since we've imported a new profile, in all likelihood, any of the current
% ClusterInfo settings are void
disp('Clearing all ClusterInfo settings.')
ClusterInfo.clear
ClusterInfo.setUserNameOnCluster(uname)

lNotifyUserOfCluster(upper(cluster))

% % Validate if you want to
% profiles = parallel.clusterProfiles();
% idx = strcmp(profiles,profile);
% ps = parallel.Settings;
% ps.Profiles(idx).validate

end


function pfile = lExtractPfile(pl)

len = length(pl);
for pidx = 1:len
    name = pl(pidx).name;
    names{pidx,1} = strtok(name,'_'); %#ok<AGROW>
end

selected = false;
while selected==false
    for pidx = 1:len
        fprintf('\t[%d] %s\n',pidx,names{pidx});
    end
    idx = input(sprintf('Select a cluster [1-%d]: ',len));
    selected = idx>=1 && idx<=len;
end
pfile = pl(idx).name;

end


function lNotifyUserOfCluster(cluster) %#ok<INUSD>

fprintf('\n');

end
