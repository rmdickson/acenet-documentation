function asa = getAdditionalSubmitArguments(props)

% http://www.ace-net.ca/wiki/Placentia
% http://www.ace-net.ca/wiki/Matlab_Instructions_2013

% Copyright 2010-2014 The MathWorks, Inc.

asa = '';

% Check if we're running parallel (matlabpool, parfor, spmd)
[~,flag] = strtok(props.MatlabArguments,'p');
isParallel = strcmp(flag,'parallel');

if isParallel==true
    w = props.NumberOfTasks;
else
    % jobs/tasks
    w = 1;
end
asa = [asa sprintf('-pe matlab %d', w)];


%% REQUIRED


%% OPTIONAL

% Query for the Walltime
wt = ClusterInfo.getWallTime();
if isempty(wt)==true
    % h_rt sets the hard time limit
    % Default: 48 hours
    % hh:mm:ss
    asa = [asa ' -l h_rt=48:0:0'];
else
    asa = [asa ' -l h_rt=' wt];
end

% Check mem per process
mu = ClusterInfo.getMemUsage();
if isempty(mu)==true
    % h_vmem sets the hard memory limit per parallel process
    % Default: 3G
    asa = [asa ' -l h_vmem=3G'];
else
    asa = [asa ' -l h_vmem=' mu];
end

% Check if user wants email updates
ea = ClusterInfo.getEmailAddress();
if isempty(ea)==false
    % User wants to be emailed the job status
    asa = [asa ' -M ' ea ' -m abes'];
end

% Every job is going to require a certain number of MDCS licenses
% Specifing one MDCS per core
asa = [asa ' -l dce=1'];

% glibc ensures the job is run on a machine with an adequate
% operating system version
asa = [asa ' -l os=RHEL6'];

% Catch-all
udo = ClusterInfo.getUserDefinedOptions();
if isempty(udo)==false
    asa = [asa ' ' udo];
end

asa = strtrim(asa);
